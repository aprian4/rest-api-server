<?php

class Usulan_model extends CI_Model
{
    public function getUsulan($id = null)
    {
        if ($id === null) {
            return $this->db->get('usulan')->result_array();
        } else {
            return $this->db->get_where('usulan', ['id' => $id])->result_array();
        }
    }

    public function deleteUsulan($id)
    {
        $this->db->delete('usulan', ['id' => $id]);
        return $this->db->affected_rows();
    }

    public function createUsulan($data)
    {
        $this->db->insert('usulan', $data);
        return $this->db->affected_rows();
    }

    public function putUsulan($data, $id)
    {
        $this->db->update('usulan', $data, ['id' => $id]);
        return $this->db->affected_rows();
    }
}
