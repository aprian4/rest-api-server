<?php

use Restserver\Libraries\REST_Controller;

defined('BASEPATH') or exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class Usulan extends REST_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Usulan_model', 'usulan');
        $this->methods['index_get']['limit'] = 2000;
    }

    public function index_get()
    {
        $id = $this->get('id');
        if ($id === null) {
            $usulan = $this->usulan->getUsulan();
        } else {
            $usulan = $this->usulan->getUsulan($id);
        }

        if ($usulan) {
            $this->response([
                'status' => true,
                'data' => $usulan
            ], REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'Gagal ambil data, id tidak ditemukan'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }

    public function index_delete()
    {
        $id = $this->delete('id');
        if ($id === null) {
            $this->response([
                'status' => false,
                'message' => 'Silahkan pilih id'
            ], REST_Controller::HTTP_BAD_REQUEST);
        } else {
            if ($this->usulan->deleteUsulan($id) > 0) {
                $this->response([
                    'status' => true,
                    'id' => $id,
                    'message' => 'usulan berhasil dihapus'
                ], REST_Controller::HTTP_OK);
            } else {
                $this->response([
                    'status' => false,
                    'message' => 'Gagal menghapus data, id tidak ditemukan'
                ], REST_Controller::HTTP_BAD_REQUEST);
            }
        }
    }

    public function index_post()
    {
        $data = [
            'id_user' => $this->post('id_user'),
            'jenis_usulan' => $this->post('jenis_usulan'),
            'status_usulan' => $this->post('status_usulan'),
        ];

        if ($this->usulan->createUsulan($data) > 0) {
            $this->response([
                'status' => true,
                'message' => 'Usulan berhasil ditambahkan'
            ], REST_Controller::HTTP_CREATED);
        } else {
            $this->response([
                'status' => false,
                'message' => 'Gagal Menambahkan data'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    public function index_put()
    {
        $id = $this->put('id');
        $data = [
            'id_user' => $this->put('id_user'),
            'jenis_usulan' => $this->put('jenis_usulan'),
            'status_usulan' => $this->put('status_usulan'),
        ];

        if ($this->usulan->putUsulan($data, $id) > 0) {
            $this->response([
                'status' => true,
                'message' => 'Usulan berhasil diubah'
            ], REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'Gagal Mengubah data'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }
}
